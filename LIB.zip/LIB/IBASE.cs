﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIB; 
public interface IBASE_GUITARE {
    Task<GUITARE> Add_Guitare(decimal prixTotal,int idMicroBridge,int idMicroCentral,int idBoisManche,int idBoisTouche,
        int idUtilisateur,int idMicroNeck,int idVibrato,int idBoisCorps);
    Task<int> Delete_Guitare(int idGuitare);
    Task<GUITARE[]> Get_All_Guitare();
    Task<GUITARE> Get_Guitare_By_Id(int P_Id);
    Task<GUITARE> Update_Guitare(int idGuitare,decimal prixTotal,int idMicroBridge,int idMicroCentral,int idBoisManche,
        int idBoisTouche,int idUtilisateur,int idMicroNeck,int idVibrato,int idBoisCorps);
}